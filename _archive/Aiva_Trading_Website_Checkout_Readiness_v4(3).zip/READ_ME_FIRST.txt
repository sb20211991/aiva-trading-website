AIVA TRADING LIMITED — FULL WEBSITE CHECKOUT PACKAGE

THIS IS THE COMPLETE AIVA TRADING WEBSITE PACKAGE (Cloudflare Pages).

PRESERVED:
- Original homepage index.html, website design and branding unchanged.
- All original 87 archive entries, byte-for-byte unchanged.
- Original supplier and customer enquiry flows, all range pages, contact forms,
  original photos, logos, language switcher, Buying Guide and Shop page.
- Paths are rooted at ZIP top level so index.html and _worker.js are at root.
- All local HTML asset and page paths have been checked for missing files.

SHOP/CHECKOUT:
- Buying Guide displays bank-card, Apple Pay and Google Pay entry options.
- Shop provides browsing, filters, basket and Stripe Checkout integration code.
- The presence of a payment button does NOT mean a payment method is live or eligible.
- Wallet availability depends on Stripe and the customer's compatible device/browser.

STATUS: NOT READY FOR REAL CUSTOMER PAYMENTS AND NOT DEPLOYED BY BUILDING THIS FILE.
- The product catalogue is empty and shopEnabled=false by design.
- Live Stripe credentials, Cloudflare D1 order database, webhook secret and valid
  shipping/returns settings are required; connected Stripe was TEST mode.
- Never put private Stripe keys in a ZIP or chat.
- Back up the existing deployment, deploy to the Aiva Trading Pages project
  as a PREVIEW, test all site pages, then promote to production when confirmed.
- Do NOT upload this website ZIP into the separate Aiva Pocket Hub app project.

SETUP: See CHECKOUT-v3-BUYING-GUIDE.txt, MERCHANT-SETUP-CHECKLIST.txt,
CHECKOUT-v2-SETUP.txt and ORDER-DATABASE-SETUP.sql in this ZIP.
This package alone does not activate billing or perform live Stripe verification.
