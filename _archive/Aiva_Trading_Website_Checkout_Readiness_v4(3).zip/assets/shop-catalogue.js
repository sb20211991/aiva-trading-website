// Use confirmed business information and retail prices in pence.
// Each item needs sku, name, category, description, pricePence, available,
// checkoutUrl (live Stripe Payment Link), and optionally image and specifications.
window.aivaShop = {
  businessAddress: '',
  delivery: '',
  returns: '',
  products: []
};
