-- Run ONCE in Cloudflare D1 Console, then bind database to Pages project as ORDERS_DB.
-- The database holds customer contact, order and delivery data: restrict access.
CREATE TABLE IF NOT EXISTS orders (
  session_id TEXT PRIMARY KEY,
  last_event_id TEXT NOT NULL,
  payment_status TEXT NOT NULL CHECK(payment_status IN ('pending','paid','failed')),
  fulfillment_status TEXT NOT NULL DEFAULT 'new' CHECK(fulfillment_status IN ('new','processing','shipped','cancelled','refunded')),
  customer_email TEXT,
  customer_name TEXT,
  amount_total INTEGER,
  currency TEXT,
  shipping_details_json TEXT,
  line_items_json TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS stripe_events (
  event_id TEXT PRIMARY KEY,
  processed_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS orders_payment_created ON orders(payment_status,created_at);
