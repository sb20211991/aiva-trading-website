/* Aiva Trading Cloudflare Pages advanced-mode Worker.
   All non-API requests are served unmodified from the existing static site. */
const JSON_HEADERS = {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const respond=(obj,status=200)=>new Response(JSON.stringify(obj),{status,headers:JSON_HEADERS});
const str=x=>typeof x==='string'?x.trim():'';
const validPrice=n=>Number.isSafeInteger(n)&&n>0&&n<=100000000;
const validStock=n=>Number.isSafeInteger(n)&&n>=0&&n<=100000;
const validSku=s=>typeof s==='string'&&/^[A-Za-z0-9_-]{2,60}$/.test(s);
const safeCountries=c=>Array.isArray(c)&&c.length>0&&c.length<=12&&c.every(x=>typeof x==='string'&&/^[A-Z]{2}$/.test(x));
function isLiveInfrastructureReady(env){return /^whsec_[A-Za-z0-9]+$/.test(str(env.STRIPE_WEBHOOK_SECRET)) && !!env.ORDERS_DB && typeof env.ORDERS_DB.prepare==='function';}
function getMode(env){const key=str(env.STRIPE_SECRET_KEY);return /^sk_live_[A-Za-z0-9]+$/.test(key)?'live':/^sk_test_[A-Za-z0-9]+$/.test(key)?'test':'disabled';}
/* A live key is NOT proof that Stripe has activated this merchant.
   Before offering live checkout, ask Stripe itself for the account status.
   Never disclose keys, account data, or KYC details to the browser. */
async function liveAccountReadiness(env){
 if(getMode(env)!=='live')return false;
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),7000);
 try{
  const response=await fetch('https://api.stripe.com/v1/account',{
   method:'GET',
   headers:{Authorization:'Bearer '+str(env.STRIPE_SECRET_KEY)},
   signal:controller.signal
  });
  if(!response.ok)return false;
  const account=await response.json();
  return account?.charges_enabled===true&&account?.payouts_enabled===true&&account?.details_submitted===true;
 }catch{return false}finally{clearTimeout(timer)}
}

function validPolicy(c){return c&&c.shopEnabled===true&&c.currency==='GBP'&&Array.isArray(c.products)&&str(c.businessAddress).length>=8&&str(c.deliveryPolicy).length>=15&&str(c.returnsPolicy).length>=15&&c.shipping&&safeCountries(c.shipping.allowedCountries)&&Number.isSafeInteger(c.shipping.flatRatePence)&&c.shipping.flatRatePence>=0&&c.shipping.flatRatePence<=100000&& (c.shipping.freeShippingThresholdPence===null||c.shipping.freeShippingThresholdPence===undefined||validPrice(c.shipping.freeShippingThresholdPence));}
function buyable(p){return p&&validSku(p.sku)&&typeof p.name==='string'&&p.name.trim().length>1&&p.name.length<=140&&typeof p.description==='string'&&p.description.length<=700&&typeof p.category==='string'&&p.category.length<=80&&p.available===true&&validPrice(p.pricePence)&&validStock(p.stock)&&p.stock>0;}
async function getCatalogue(request,env){const url=new URL(request.url);url.pathname='/data/aiva-products.json';url.search='';const r=await env.ASSETS.fetch(new Request(url.toString(),{method:'GET'}));if(!r.ok)throw Error('CATALOGUE_UNAVAILABLE');return await r.json();}
function paramsAppend(params,key,val){params.append(key,String(val));}
async function createCheckout(request,env,cat,mode){
 if(request.method!=='POST')return respond({error:'Method not allowed.'},405);
 if(mode==='disabled'||!validPolicy(cat)||mode==='live'&&!isLiveInfrastructureReady(env))return respond({error:'Online checkout is not enabled. Contact Aiva for a quotation.'},503);
 if(mode==='live'&&!await liveAccountReadiness(env))return respond({error:'Merchant live payments are not yet enabled by Stripe. Please contact Aiva.'},503);
 const origin=request.headers.get('Origin');const site=new URL(request.url);if(origin&&origin!==site.origin)return respond({error:'Untrusted request origin.'},403);
 if(!/application\/json/i.test(request.headers.get('Content-Type')||''))return respond({error:'Send JSON checkout items.'},415);
 if(Number(request.headers.get('Content-Length'))>8192)return respond({error:'Order too large.'},413);
 let data;try{data=await request.json()}catch{return respond({error:'Invalid order format.'},400)}
 if(!data||!Array.isArray(data.items)||data.items.length<1||data.items.length>20)return respond({error:'Choose 1–20 products.'},400);
 const prices=new Map(cat.products.filter(buyable).map(p=>[p.sku,p]));const used=new Set();let itemTotal=0,totalUnits=0;
 const values=new URLSearchParams();
 paramsAppend(values,'mode','payment');paramsAppend(values,'success_url',site.origin+'/order-success.html?session_id={CHECKOUT_SESSION_ID}');paramsAppend(values,'cancel_url',site.origin+'/shop.html?cancelled=1#aiva-basket');
 paramsAppend(values,'billing_address_collection','required');paramsAppend(values,'phone_number_collection[enabled]','true');paramsAppend(values,'customer_creation','always');
 paramsAppend(values,'metadata[source]','aivatrading.uk');
 paramsAppend(values,'payment_intent_data[metadata][source]','aivatrading.uk');
 for(const [i,item] of data.items.entries()){
  const sku=item&&item.sku,qty=item&&item.quantity,p=prices.get(sku);
  if(!validSku(sku)||!p||used.has(sku)||!Number.isSafeInteger(qty)||qty<1||qty>10||qty>p.stock)return respond({error:'Your basket contains an unavailable product or quantity.'},400);
  used.add(sku);totalUnits+=qty;itemTotal+=p.pricePence*qty;
  if(itemTotal>200000000||totalUnits>50)return respond({error:'Order total exceeds the online limit; request a quotation.'},400);
  const x='line_items['+i+']';
  paramsAppend(values,x+'[price_data][currency]','gbp');paramsAppend(values,x+'[price_data][unit_amount]',p.pricePence);
  paramsAppend(values,x+'[price_data][product_data][name]',p.name.trim());
  paramsAppend(values,x+'[price_data][product_data][description]',p.description.slice(0,400));
  paramsAppend(values,x+'[price_data][product_data][metadata][sku]',p.sku);
  paramsAppend(values,x+'[quantity]',qty);
 }
 const shipping=cat.shipping;
 const shippingPrice=(Number.isSafeInteger(shipping.freeShippingThresholdPence)&&itemTotal>=shipping.freeShippingThresholdPence)?0:shipping.flatRatePence;
 for(let i=0;i<shipping.allowedCountries.length;i++)paramsAppend(values,`shipping_address_collection[allowed_countries][${i}]`,shipping.allowedCountries[i]);
 paramsAppend(values,'shipping_options[0][shipping_rate_data][type]','fixed_amount');
 paramsAppend(values,'shipping_options[0][shipping_rate_data][fixed_amount][currency]','gbp');
 paramsAppend(values,'shipping_options[0][shipping_rate_data][fixed_amount][amount]',shippingPrice);
 paramsAppend(values,'shipping_options[0][shipping_rate_data][display_name]',shippingPrice===0?'Standard delivery (included)':'Standard delivery');
 paramsAppend(values,'automatic_tax[enabled]','false');
 const ctl=new AbortController();const timeout=setTimeout(()=>ctl.abort(),10000);
 try{
  const response=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{'Authorization':'Bearer '+str(env.STRIPE_SECRET_KEY),'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':'aiva_'+crypto.randomUUID()},body:values.toString(),signal:ctl.signal});
  const result=await response.json();
  if(!response.ok){console.error('Stripe create failed',response.status,result?.error?.code);return respond({error:'Secure checkout could not be started. Try again or contact Aiva.'},502)}
  const checkoutUrl=new URL(result.url);
  if(checkoutUrl.protocol!=='https:'||!checkoutUrl.hostname.endsWith('.stripe.com'))return respond({error:'Invalid payment provider response.'},502);
  return respond({url:result.url});
 }catch(e){console.error('Stripe checkout network error',String(e));return respond({error:'Payment service is temporarily unavailable.'},502)}finally{clearTimeout(timeout)}
}
async function getOrderStatus(request,env){
 if(request.method!=='GET')return respond({error:'Method not allowed.'},405);
 const id=new URL(request.url).searchParams.get('session_id');
 if(!id||!/^cs_(test_|live_)[A-Za-z0-9]+$/.test(id))return respond({error:'Invalid checkout reference.'},400);
 if(getMode(env)==='disabled')return respond({error:'Payment verification is not configured.'},503);
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),10000);
 try{
  const r=await fetch('https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(id),{headers:{Authorization:'Bearer '+str(env.STRIPE_SECRET_KEY)},signal:controller.signal});
  if(!r.ok)return respond({error:'Could not verify this payment.'},r.status===404?404:502);
  const data=await r.json();
  if(data?.metadata?.source!=='aivatrading.uk')return respond({error:'Unknown order origin.'},404);
  return respond({paid:data.payment_status==='paid',status:data.status==='complete'?'complete':'pending',reference:id.slice(-10),mode:getMode(env)});
 }catch{return respond({error:'Could not check payment status.'},502)}finally{clearTimeout(timeout)}
}
/* Stripe webhooks: signed verification against the EXACT unmodified request body. */
function timingSafeEqual(a,b){
 if(a.length!==b.length)return false;
 let different=0;for(let i=0;i<a.length;i++)different|=a.charCodeAt(i)^b.charCodeAt(i);
 return different===0;
}
async function verifyStripeSignature(raw,header,secret){
 if(!/^whsec_[A-Za-z0-9]+$/.test(secret)||!header)return false;
 const pieces=header.split(',').map(x=>x.trim());
 const times=pieces.filter(x=>x.startsWith('t=')).map(x=>x.slice(2));
 const sigs=pieces.filter(x=>x.startsWith('v1=')).map(x=>x.slice(3));
 if(times.length!==1||!sigs.length||!/^\d+$/.test(times[0]))return false;
 const stamp=Number(times[0]);
 if(!Number.isSafeInteger(stamp)||Math.abs(Math.floor(Date.now()/1000)-stamp)>300)return false;
 const encoder=new TextEncoder();
 const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const signed=new Uint8Array(await crypto.subtle.sign('HMAC',key,encoder.encode(times[0]+'.'+raw)));
 const expected=Array.from(signed).map(x=>x.toString(16).padStart(2,'0')).join('');
 return sigs.some(x=>/^[0-9a-f]{64}$/.test(x)&&timingSafeEqual(x,expected));
}
async function stripeLineItems(sessionId,env){
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);
 try{
  const endpoint='https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(sessionId)+'/line_items?limit=100';
  const r=await fetch(endpoint,{headers:{'Authorization':'Bearer '+str(env.STRIPE_SECRET_KEY)},signal:controller.signal});
  if(!r.ok)throw Error('Stripe line items unavailable');
  const data=await r.json();
  if(data.has_more)throw Error('Order has more line items than can be saved safely');
  return (data.data||[]).map(x=>({description:String(x.description||'').slice(0,200),quantity:Number(x.quantity||0),subtotal:Number(x.amount_subtotal||0),currency:String(x.currency||'gbp')}));
 }finally{clearTimeout(timer)}
}
async function stripeWebhook(request,env){
 if(request.method!=='POST')return respond({error:'Method not allowed.'},405);
 if(!isLiveInfrastructureReady(env) && !(getMode(env)==='test' && str(env.STRIPE_WEBHOOK_SECRET).startsWith('whsec_')&&env.ORDERS_DB?.prepare))return respond({error:'Webhook not configured.'},503);
 if(Number(request.headers.get('Content-Length'))>128000)return respond({error:'Webhook payload too large.'},413);
 const raw=await request.text();if(raw.length>128000)return respond({error:'Webhook payload too large.'},413);
 if(!await verifyStripeSignature(raw,request.headers.get('Stripe-Signature'),str(env.STRIPE_WEBHOOK_SECRET)))return respond({error:'Invalid signature.'},400);
 let event;try{event=JSON.parse(raw)}catch{return respond({error:'Invalid JSON.'},400)}
 if(!event?.id||!/^evt_[A-Za-z0-9]+$/.test(event.id))return respond({error:'Invalid event.'},400);
 if(!['checkout.session.completed','checkout.session.async_payment_succeeded','checkout.session.async_payment_failed'].includes(event.type))return respond({received:true});
 const session=event?.data?.object;
 if(!session||!/^cs_(test_|live_)[A-Za-z0-9]+$/.test(session.id||'')||session.metadata?.source!=='aivatrading.uk')return respond({received:true});
 if(Boolean(event.livemode)!==(getMode(env)==='live')||Boolean(session.livemode)!==(getMode(env)==='live'))return respond({error:'Payment mode mismatch.'},400);
 const paid=event.type!=='checkout.session.async_payment_failed'&&session.payment_status==='paid';
 const state=paid?'paid':event.type==='checkout.session.async_payment_failed'?'failed':'pending';
 const items=paid?await stripeLineItems(session.id,env):[];
 const ship=session.shipping_details || session.collected_information?.shipping_details || null;
 // D1 is a private Cloudflare binding; no public order-list endpoint is exposed.
 // ON CONFLICT prevents payment-status downgrade when Stripe retries or sends events out of order.
 await env.ORDERS_DB.batch([
  env.ORDERS_DB.prepare(`INSERT OR IGNORE INTO stripe_events (event_id,processed_at) VALUES (?,?)`).bind(event.id,Math.floor(Date.now()/1000)),
  env.ORDERS_DB.prepare(`INSERT INTO orders
  (session_id,last_event_id,payment_status,customer_email,customer_name,amount_total,currency,shipping_details_json,line_items_json,created_at,updated_at)
  VALUES (?,?,?,?,?,?,?,?,?,?,?)
  ON CONFLICT(session_id) DO UPDATE SET
   last_event_id=excluded.last_event_id,
   payment_status=CASE WHEN orders.payment_status='paid' THEN 'paid' ELSE excluded.payment_status END,
   customer_email=COALESCE(orders.customer_email,excluded.customer_email),
   customer_name=COALESCE(orders.customer_name,excluded.customer_name),
   amount_total=COALESCE(excluded.amount_total,orders.amount_total),
   currency=COALESCE(excluded.currency,orders.currency),
   shipping_details_json=COALESCE(excluded.shipping_details_json,orders.shipping_details_json),
   line_items_json=CASE WHEN excluded.payment_status='paid' THEN excluded.line_items_json ELSE orders.line_items_json END,
   updated_at=excluded.updated_at`)
   .bind(session.id,event.id,state,String(session.customer_details?.email||session.customer_email||'').slice(0,320),String(session.customer_details?.name||'').slice(0,160),Number.isSafeInteger(session.amount_total)?session.amount_total:null,String(session.currency||'gbp').slice(0,5),ship?JSON.stringify(ship).slice(0,5000):null,paid?JSON.stringify(items).slice(0,20000):null,Math.floor(Date.now()/1000),Math.floor(Date.now()/1000))
 ]);
 return respond({received:true});
}

export default {
 async fetch(request,env){
  const url=new URL(request.url);
  if(url.pathname==='/api/shop-status'){
   try{const cat=await getCatalogue(request,env);const mode=getMode(env);const merchantReady=mode==='live'?await liveAccountReadiness(env):mode==='test';return respond({ready:merchantReady&&validPolicy(cat)&&cat.products.some(buyable)&&(mode==='test'||isLiveInfrastructureReady(env)),mode,merchantReady,webhookConfigured:/^whsec_[A-Za-z0-9]+$/.test(str(env.STRIPE_WEBHOOK_SECRET)),orderDatabaseConfigured:!!env.ORDERS_DB&&typeof env.ORDERS_DB.prepare==='function',publishedProducts:Array.isArray(cat.products)?cat.products.filter(buyable).length:0});}catch{return respond({ready:false,mode:'disabled',publishedProducts:0})}
  }
  if(url.pathname==='/api/create-checkout-session'){
    try{const cat=await getCatalogue(request,env);return await createCheckout(request,env,cat,getMode(env));}catch{return respond({error:'Checkout is currently unavailable.'},503)}
  }
  if(url.pathname==='/api/order-status')return await getOrderStatus(request,env);
  if(url.pathname==='/api/stripe-webhook'){try{return await stripeWebhook(request,env)}catch(e){console.error('Order webhook failed',String(e));return respond({error:'Webhook processing temporarily unavailable.'},500)}}
  if(url.pathname.startsWith('/api/'))return respond({error:'Not found'},404);
  return env.ASSETS.fetch(request);
 }
};
